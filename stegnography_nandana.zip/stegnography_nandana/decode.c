#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "common.h"

// Validate decode arguments 
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)  
{
    if (argv[2] == NULL)        
    {
        return e_failure;
    }

    int len = strlen(argv[2]);      //length of stego.bmp

    if (len < 4 || strcmp(argv[2] + len - 4, ".bmp") != 0)             //.bmp or not
    {
        return e_failure;
    }
    decInfo->stego_image_fname = argv[2];

    if (argv[3] != NULL)                    //checking third parameter is present or not
    {
        strcpy(decInfo->secret_fname, argv[3]);
    }
    else
    {
        strcpy(decInfo->secret_fname, "output");            //creating new file 
    }

    return e_success;
}


Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");

    if (decInfo->fptr_stego_image == NULL)
        return e_failure;

    return e_success;
    //opening the files
}

//Decode magic string 
Status decode_magic_string(DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;
    char magic[10];

    for (int i = 0; i < strlen(MAGIC_STRING); i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image);
        decode_byte_from_lsb(buffer, &decoded_char);
        magic[i] = decoded_char;
    }

    magic[strlen(MAGIC_STRING)] = '\0';

    if (strcmp(magic, MAGIC_STRING) != 0)
    {
        printf("ERROR: Magic string mismatch\n");
        return e_failure;
    }
    printf("Magic string decoded\n");

    return e_success;
}

// Decode extension size 
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char buffer[32];

    fread(buffer, 32, 1, decInfo->fptr_stego_image);
    decode_size_from_lsb(buffer, &decInfo->extn_size);

    return e_success;
}

// Decode extension and prepare output file 
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char buffer[8];
    char decoded_char;
    char extn[20];

    //Decode extension 
    for (int i = 0; i < decInfo->extn_size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image);
        decode_byte_from_lsb(buffer, &decoded_char);
        extn[i] = decoded_char;
    }

    extn[decInfo->extn_size] = '\0';

    
    if (strstr(decInfo->secret_fname, extn) == NULL)
    {
        strcat(decInfo->secret_fname, extn);
    }

   
    decInfo->fptr_secret = fopen(decInfo->secret_fname, "w");

    if (decInfo->fptr_secret == NULL)
        return e_failure;

    return e_success;
}


//Decode secret file size 
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char buffer[32];

    fread(buffer, 32, 1, decInfo->fptr_stego_image);
    decode_size_from_lsb(buffer, (int *)&decInfo->secret_file_size);

    return e_success;
}

 //Decode secret file data 
Status decode_secret_file_data(DecodeInfo *decInfo) 
{
    char buffer[8];
    char decoded_char;

    for (long i = 0; i < decInfo->secret_file_size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image);
        decode_byte_from_lsb(buffer, &decoded_char);
        fwrite(&decoded_char, 1, 1, decInfo->fptr_secret);
    }

    return e_success;
}


Status decode_byte_from_lsb(char *buffer, char *data)           //extracting  1 byte character from lsb
{
    *data = 0;

    for (int i = 0; i < 8; i++)
    {
        *data = (*data << 1) | (buffer[i] & 1);
    }

    return e_success;
}


Status decode_size_from_lsb(char *buffer, int *size)        //extracting 32 bytes from lsb
{
    *size = 0;

    for (int i = 0; i < 32; i++)
    {
        *size = (*size << 1) | (buffer[i] & 1);
    }

    return e_success;
}
Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_failure)
    {
        return e_failure;
    }
    printf("Files openend successfully\n");
    
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);     //remove header of bmp file

   
    if (decode_magic_string(decInfo) == e_failure)          //call the decode magic string function
    {
       return e_failure;
    }


    
    if (decode_secret_file_extn_size(decInfo) == e_failure)     //call decode_secret_file_extn_size
    {
        return e_failure;
    }
    printf("Decoded secret file extension size successfully\n");

    
    if (decode_secret_file_extn(decInfo) == e_failure)      //call decode_secret_file_extn
    {
       return e_failure;
    }
    printf("Decoded secret file extension successfully\n");

    
    if (decode_secret_file_size(decInfo) == e_failure)          //call decode_secret_file_size
    {
        return e_failure;
    }
    printf("Decoded secret file size successfully\n");

    
    if (decode_secret_file_data(decInfo) == e_failure)      //call decode_secret_file_data
    {
        return e_failure;
    }
    printf("Decoded secret file data successfully\n");

    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_secret);

    

    return e_success;
}

