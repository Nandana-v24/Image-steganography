#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"

/* Structure for Decode */
typedef struct _DecodeInfo
{
    /* Input stego image */
    char *stego_image_fname;
    FILE *fptr_stego_image;

    /* Output secret file */
    char secret_fname[100];
    FILE *fptr_secret;

    /* Decoded values */
    int extn_size;
    long secret_file_size;

} DecodeInfo;


Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);


Status open_decode_files(DecodeInfo *decInfo);


Status do_decoding(DecodeInfo *decInfo);


Status decode_magic_string(DecodeInfo *decInfo);


Status decode_secret_file_extn_size(DecodeInfo *decInfo);


Status decode_secret_file_extn(DecodeInfo *decInfo);


Status decode_secret_file_size(DecodeInfo *decInfo);


Status decode_secret_file_data(DecodeInfo *decInfo);



Status decode_byte_from_lsb(char *buffer, char *data);


Status decode_size_from_lsb(char *buffer, int *size);

#endif

