/*
Nandana V
16 February 2026
This project is related to hide a data in a image.In this project encoding the data in a image and decoding the 
data from that.
sample output for encoding:
File opened successfully
width = 1024
height = 768
Checking Capacity is successfull
Copy header successfully
Magic string succesfull
Secret file extension size successfull
File extension succesfull
Secret file size successfull
Secret file successfull
Encoded successfully

sample output in decoding:
Files openend successfully
Magic string decoded
Decoded secret file extension size successfully
Decoded secret file extension successfully
Decoded secret file size successfully
Decoded secret file data successfully
Decoding completed successfully
*/

#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    //step1 -> check_operation_type(argv[1])
    OperationType optype =  check_operation_type(argv[1]);

    if(optype==e_encode)
    {
        EncodeInfo encInfo;
    //step2 -> check the return value == e_encode
            //declare structure variable EncodeInfo encInfo
            if(read_and_validate_encode_args(argv,&encInfo)==e_failure)
            {
                printf("Invalid encode argument\n");
                return 1;
            }
            //--> read_and_validate_encode_args(pass command line arg, &encInfo) == e_success or e_failure
            // e_failure -> print error msg and stop the program
            // e_success -> next step.
            if(do_encoding(&encInfo)==e_failure)
            {
                printf("Encoding failed\n");
                return 1;
            }
            

           
        // call do_encoding(&encInfo);
            //e_failure -> print error msg and stop the program
            //e_success -> print success msg and stop the program
    }
    else if(optype==e_decode)
    {
        //step3 -> return value == e_decode
        DecodeInfo decInfo;   // <-- Declare structure

        if (read_and_validate_decode_args(argv, &decInfo) == e_failure)
        {
            printf("Invalid decode arguments\n");
            return 1;
        }

        if (do_decoding(&decInfo) == e_failure)
        {
            printf("Decoding failed\n");
            return 1;
        }

        printf("Decoding completed successfully\n");
    }
    

    else
    {
        printf("Unsupported\n");
        //step3 -> return value == e_unsupported
            // --> print invalid arg
            // -e -> encode
            // -d  -> decode
         
    }
}
    


OperationType check_operation_type(char *symbol)
{
    //step1 -> check it is -e or -d 
    if(strcmp(symbol,"-e")==0)
    {
        return e_encode;
    }
    // if it is -e return e_encode
    // else if it is -d rteun e_decode
    else if(strcmp(symbol,"-d")==0)
    {
        return e_decode;
    }
    // else return e_unsuported
    else
    {
        return e_unsupported;
    }
}
